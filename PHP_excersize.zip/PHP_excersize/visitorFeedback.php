<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>Visitor feedback</title>
</head>
<body>
    <h2> Visitor feedback</h2>
    <?php
        $dir = "./comments";
        if(is_dir($dir)){
            $commentFiles = scandir($dir);
            foreach($commentFiles as $ fileName){
                if( $fileName !== "." && $fileName !== ".."){
                    echo "from <strong>$fileName</strong><br>";
                    echo "<pre>\n";
                    $comment = file_get_contents($dir . "/" . $fileName);
                    echo $comment;
                    echo "</pre>\n";
                    echo "<hr>\n";
                }
            }
        }
    ?>

</body>
</html>