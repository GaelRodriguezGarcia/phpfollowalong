<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>File Download Error</title>
</head>
<body>
    <h2>File Download Error</h2>
    <?php
    
    $dir = "../PHP_excersize";
    if (isset($_GET[fileName])){
        $filetoGet = $dir . "/" . striplashes($_GET[fileName]);
        if(is_readable($filetoGet)){
            header("content-description: file transfer");
            header("content-type: application/force-download");
            header("content-disposition: attachment: filename= \"") .
            $_GET('fileName') . "\"";
            header("content-transfer-encoding: base64: file transfer");
            header("content-length: file transfer ". filesize($filetoGet));
            readfile($filetoGet);
            $showErrorPage = false;
            $errorMsg = "";

        } else {}    $errorMsg = "";
            $showErrorPage = true;
        } else {
            $errorMsg = "Cannot read \"$filetoGet\"";
            $showErrorPage = true;
        }
    } else {
        $errorMsg = "No filename specified";
        $showErrorPage = true;
    }
    if($showErrorPage){

    }


    ?>
    <h2>File downloader</h2>
    <p>there was an error downloading "<?php echo
    htmlentities($_GET['filename']);</p>
    <p><?php echo htmlentities($errorMsg);?></p>
</body>
</html>