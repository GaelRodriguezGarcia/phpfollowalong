<!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>Visitor Comments3</title>
</head>
<body>
    <h2> Visitor comments3</h2>
    <hr>
    <?php
    $dir = "./comments";
            if(is_dir($dir)){
                if(isset($_POST['save'])){
                    if(empty($_POST['name'])){
                        echo "Unknown visitor\n";
                    }else{
                        $saveString = stripslashes($_POST['name']) . "\n";
                        $saveString .= stripslashes($_POST['email']) . "\n";
                        $saveString .= date('r') . "\n";
                        $saveString .= stripslashes($_POST['comment']) . "\n";
                        echo "\$saveString: $saveString<br>";
                        $currentTime = microtime();
                        echo "$currentTime : $currentTime <br>";
                        $timeArray = explode(" ", $currentTime);
                        echo var_dump($timeArray) . "<br>";
                        $timeStamp = (float)$timeArray[1] +
                            (float)$timeArray[0];
                        echo "\$timeStamp: $timeStamp <br>";
                        $saveFileName = "$dir/comment.$timeStamp.txt";
                        echo "\$saveFileName: SaveFileName <br>";
                        $fileHandle = fopen($saveFileName, "wb");
                        if( $fileHandle === false) {
                            echo "there was an error creating \"" .
                            htmlentities($saveFileName) . "\".<br>\n";
                        } else {
                            if(flock($fileHandle, LOCK_EX)) {   
                        } else {
                            if(fwrite( $fileHandle, $saveString)) > 0 {
                                echo "sussesfully wrote to file \"" .
                                htmlentities($saveFileName) . "\".<br>\n";
                        } else{
                            echo "There was an error writing to \"" .
                                htmlentities($saveFileName) . "\".<br>\n";
                        }
                        flock($fileHandle, Lock_UN);
                    }else {
                        echo "there was an error locking this file \"
                    }
                        fclose($fileHandle);
                        }
                    }
                }
            }
    ?>
    <form action="VisistorComments3.php" method = "post">
    your name: <imput type = "text" name = "name"><br>
    your email <input type = "text" name = "email"><br>
    <textarea name = "comment" rows = "6" cols = "100"></textarea<br>
    <input type = "submit" name = "save" value= "submit your comment"><br>
    </form>
</body>