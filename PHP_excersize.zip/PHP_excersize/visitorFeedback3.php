<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>Visitor feedback 3</title>
</head>
<body>
    <h2> Visitor feedback 3</h2>
    <?php
        $dir = "./comments";
        if(is_dir($dir)){
            $commentFiles = scandir($dir);
            foreach($commentFiles as $ fileName){
                if( $fileName !== "." && $fileName !== ".."){
                    echo "from <strong>$fileName</strong><br>";
                    $comment = file($dir . "/" . $fileName);
                    echo "from:" . htmlentities($comment[0]) . "<br>\n"
                    echo "Email address" . htmlentities($comment[1]) . "<br>\n"
                    echo "date" . htmlentities($comment[2]) . "<br>\n"
                    $commentLines = count($commentLines; $i++){
                        echo htmlentities($comment[$i]) . "<br>\n"
                    }
                    
                    echo $comment;
                    
                    echo "<hr>\n";
                }
            }
        }
    ?>

</body>
</html>