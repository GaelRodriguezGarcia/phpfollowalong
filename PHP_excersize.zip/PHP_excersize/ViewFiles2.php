<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>View Files 2</title>
</head>
<body>
    <h2>View Files 2</h2>
    <?php
        $dir = "../PHP EXCERSIZE";
        $dirEntries = scandir($dir);
        foreach($dirEntries as $entry){
            if(strcmp($curFile, '.') !== 0 && strcmp($curFile, '..')!==0){
            echo "<a href=\$dir/$entry\">$entry</a><br>\n";
            }
        }
        closedir($openDir)
    ?>
</body>
</html>