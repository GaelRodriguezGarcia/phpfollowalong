<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--
        Author:Gael Rodriguez
        Date: 11/17/2020
        Assignment: PHP Files and perms
    -->
    <title>View Files</title>
</head>
<body>
    <h2>view files</h2>
    <?php
        $dir = "../PHP_EXCERSIZE";
        $dirEntries = scandir($dir);
        while($curFile = readdir($entry)){
            if(strcmp($entry, '.') !== 0 && strcmp($entry, '..')!==0){
                echo "<a href=\"$dir/$curFile\">$curFile</a><br>\n";
            }
            
        }
        closedir($openDir)
    ?>
</body>
</html>